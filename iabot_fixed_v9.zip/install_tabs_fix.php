<?php
/**
 * Script de correction pour l'installation des onglets d'administration
 * 
 * Ce script doit être exécuté après l'installation du module pour corriger les onglets d'administration
 */

// Vérifier si le module est installé
if (!defined('_PS_VERSION_')) {
    include(dirname(__FILE__) . '/../../config/config.inc.php');
    include(dirname(__FILE__) . '/../../init.php');
}

// Vérifier si la classe Tab existe
if (!class_exists('Tab')) {
    die('La classe Tab n\'existe pas');
}

// Définition des onglets à installer
$tabs = [
    [
        'class_name' => 'AdminIaBotDashboard',
        'parent_class_name' => 'IMPROVE',
        'name' => 'IaBot - Tableau de bord',
        'icon' => 'dashboard',
        'visible' => true
    ],
    [
        'class_name' => 'AdminIaBotConfiguration',
        'parent_class_name' => 'AdminIaBotDashboard',
        'name' => 'Configuration',
        'icon' => 'settings',
        'visible' => true
    ],
    [
        'class_name' => 'AdminIaBotKnowledge',
        'parent_class_name' => 'AdminIaBotDashboard',
        'name' => 'Base de connaissances',
        'icon' => 'book',
        'visible' => true
    ],
    [
        'class_name' => 'AdminIaBotRecommendations',
        'parent_class_name' => 'AdminIaBotDashboard',
        'name' => 'Recommandations',
        'icon' => 'star',
        'visible' => true
    ],
    [
        'class_name' => 'AdminIaBotStatistics',
        'parent_class_name' => 'AdminIaBotDashboard',
        'name' => 'Statistiques',
        'icon' => 'assessment',
        'visible' => true
    ],
    [
        'class_name' => 'AdminIaBotFixPermissions',
        'parent_class_name' => 'AdminIaBotDashboard',
        'name' => 'Réparer les permissions',
        'icon' => 'build',
        'visible' => true
    ]
];

// Installation de chaque onglet
foreach ($tabs as $tabData) {
    // Vérifier si l'onglet existe déjà
    $tabId = Tab::getIdFromClassName($tabData['class_name']);
    if ($tabId) {
        // Supprimer l'onglet existant
        $tab = new Tab($tabId);
        $tab->delete();
    }
    
    // Créer un nouvel onglet
    $tab = new Tab();
    $tab->active = isset($tabData['visible']) ? (bool)$tabData['visible'] : true;
    $tab->class_name = $tabData['class_name'];
    $tab->name = array();
    $tab->module = 'iabot';
    
    if (isset($tabData['icon'])) {
        $tab->icon = $tabData['icon'];
    }
    
    // Déterminer l'ID parent
    if (isset($tabData['parent_class_name'])) {
        $parentId = Tab::getIdFromClassName($tabData['parent_class_name']);
        if ($parentId) {
            $tab->id_parent = $parentId;
        } else {
            // Si le parent n'existe pas, utiliser le parent par défaut
            $tab->id_parent = 0;
        }
    } else {
        $tab->id_parent = 0;
    }
    
    // Définir les noms dans toutes les langues
    foreach (Language::getLanguages() as $lang) {
        if (isset($lang['id_lang'])) {
            $tab->name[$lang['id_lang']] = $tabData['name'];
        }
    }
    
    // Enregistrer l'onglet
    $tab->save();
    
    echo "Onglet {$tabData['class_name']} installé avec succès<br>";
}

echo "Tous les onglets ont été installés avec succès";