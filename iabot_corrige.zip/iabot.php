<?php
/**
 * Module IaBot pour PrestaShop
 *
 * @author    IaBot Team
 * @copyright 2023 IaBot
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

// Définir les constantes nécessaires si elles n'existent pas
if (!defined('_PS_ROOT_DIR_')) {
    define('_PS_ROOT_DIR_', dirname(__FILE__, 3));
}

if (!defined('_PS_CACHE_DIR_')) {
    define('_PS_CACHE_DIR_', _PS_ROOT_DIR_ . '/var/cache/');
}

if (!defined('_COOKIE_KEY_')) {
    define('_COOKIE_KEY_', 'iabot_default_key');
}

// Définition de l'interface WidgetInterface si elle n'existe pas
if (!interface_exists('WidgetInterface')) {
    interface WidgetInterface
    {
        public function renderWidget(string $hookName, array $configuration): string;
        public function getWidgetVariables(string $hookName, array $configuration): array;
    }
}

// Import des classes PrestaShop nécessaires
use PrestaShopBundle\Controller\Admin\Sell\Catalog\Product\ProductController;
use PrestaShopBundle\Form\Admin\Type\SwitchType;
use PrestaShopBundle\Form\Admin\Type\TranslatableType;
use PrestaShopBundle\Form\Admin\Type\TranslatorAwareType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Classe principale du module IaBot
 */
class IaBot extends Module implements WidgetInterface
{
    /**
     * @var string Nom du module
     */
    public $name;
    
    /**
     * @var string Onglet du module
     */
    public $tab;
    
    /**
     * @var string Version du module
     */
    public $version;
    
    /**
     * @var string Auteur du module
     */
    public $author;
    
    /**
     * @var int Besoin d'instance
     */
    public $need_instance;
    
    /**
     * @var bool Utilisation du bootstrap
     */
    public $bootstrap;
    
    /**
     * @var string Nom affiché du module
     */
    public $displayName;
    
    /**
     * @var string Description du module
     */
    public $description;
    
    /**
     * @var string Message de confirmation de désinstallation
     */
    public $confirmUninstall;
    
    /**
     * @var array Compatibilité des versions de PrestaShop
     */
    public $ps_versions_compliancy;
    
    /**
     * @var string Chemin du module
     */
    public $_path;
    
    /**
     * @var int ID du module
     */
    public $id;
    
    /**
     * @var \Context|null Instance du contexte PrestaShop
     */
    protected $context;
    
    /**
     * @var \Controller|null Contrôleur actuel
     */
    protected $controller;
    
    /**
     * @var \Customer|null Client actuel
     */
    protected $customer;
    
    /**
     * @var \Cart|null Panier actuel
     */
    protected $cart;
    
    /**
     * @var \Currency|null Devise actuelle
     */
    protected $currency;
    
    /**
     * @var \Smarty|null Instance de Smarty
     */
    protected $smarty;
    
    /**
     * @var \Employee|null Employé actuel
     */
    protected $employee;
    
    /**
     * @var \Db|null Instance de la base de données
     */
    protected $db;
    
    /**
     * @var string Icône du module
     */
    protected $icon;
    
    /**
     * @var array|string Libellés du module
     */
    protected $wording;
    
    /**
     * @var string Domaine de traduction
     */
    protected $wording_domain;
    
    /**
     * @var array Liste des hooks utilisés par le module
     */
    protected $hooks = [
        'displayBeforeBodyClosingTag',
        'displayHeader',
        'displayFooter',
        'displayProductAdditionalInfo',
        'displayBackOfficeHeader',
        'actionAuthentication',
        'actionCustomerLogoutAfter',
        'actionProductAdd',
        'actionProductUpdate',
        'actionProductDelete',
        'actionCategoryAdd',
        'actionCategoryUpdate',
        'actionCategoryDelete',
        'actionOrderStatusUpdate'
    ];
    
    /**
     * @var array Configuration des onglets d'administration
     */
    protected $tabConfig = [
        [
            'name' => 'Configuration IaBot',
            'class_name' => 'AdminIaBotConfiguration',
            'visible' => true,
            'parent_class_name' => 'AdminParentModulesSf'
        ]
    ];

    /**
     * Constructeur du module
     */
    public function __construct()
    {
        $this->name = 'iabot';
        $this->tab = 'front_office_features';
        $this->version = '1.0.0';
        $this->author = 'IaBot Team';
        $this->need_instance = 0;
        $this->ps_versions_compliancy = [
            'min' => '1.6',
            'max' => _PS_VERSION_
        ];
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('IaBot - Assistant IA pour PrestaShop');
        $this->description = $this->l('Module d\'assistant IA pour votre boutique PrestaShop');
        $this->confirmUninstall = $this->l('Êtes-vous sûr de vouloir désinstaller ce module?');

        // Initialisation des propriétés
        $this->initializeProperties();
    }

    /**
     * Initialisation des propriétés
     */
    protected function initializeProperties()
    {
        // Initialisation des propriétés par défaut
        $this->controller = null;
        $this->customer = null;
        $this->cart = null;
        $this->currency = null;
        $this->smarty = null;
        $this->employee = null;
        $this->db = null;
        $this->icon = 'chat';
        $this->wording = [];
        $this->wording_domain = 'Modules.Iabot.Admin';
        
        // Initialisation du contexte
        if (class_exists('Context')) {
            $this->context = Context::getContext();
            
            // Initialisation des propriétés liées au contexte
            if (isset($this->context)) {
                if (isset($this->context->controller)) {
                    $this->controller = $this->context->controller;
                }
                
                if (isset($this->context->customer)) {
                    $this->customer = $this->context->customer;
                }
                
                if (isset($this->context->cart)) {
                    $this->cart = $this->context->cart;
                }
                
                if (isset($this->context->currency)) {
                    $this->currency = $this->context->currency;
                }
                
                if (isset($this->context->smarty)) {
                    $this->smarty = $this->context->smarty;
                }
                
                if (isset($this->context->employee)) {
                    $this->employee = $this->context->employee;
                }
            }
        }
        
        // Initialisation de la base de données
        if (class_exists('Db')) {
            $this->db = Db::getInstance();
        }
    }
    
    /**
     * Installation du module
     *
     * @return bool
     */
    public function install()
    {
        // Vérifier si la méthode parent existe
        if (!method_exists(parent::class, 'install')) {
            return false;
        }
        
        // Installation du module parent
        if (!parent::install()) {
            return false;
        }
        
        // Installation des tables SQL
        if (!$this->installDb()) {
            $this->uninstall();
            return false;
        }
        
        // Installation des onglets d'administration
        if (!$this->installTabs()) {
            $this->uninstall();
            return false;
        }
        
        // Enregistrement des hooks
        foreach ($this->hooks as $hook) {
            if (!$this->registerHook($hook)) {
                $this->uninstall();
                return false;
            }
        }
        
        // Configuration par défaut
        \Configuration::updateValue('IABOT_ENABLED', true);
        \Configuration::updateValue('IABOT_API_KEY', '');
        \Configuration::updateValue('IABOT_API_URL', 'https://api.iabot.ai/v1');
        \Configuration::updateValue('IABOT_POSITION', 'right');
        \Configuration::updateValue('IABOT_THEME', 'light');
        \Configuration::updateValue('IABOT_TITLE', 'Assistant IA');
        \Configuration::updateValue('IABOT_SUBTITLE', 'Comment puis-je vous aider ?');
        
        return true;
    }
    
    /**
     * Désinstallation du module
     *
     * @return bool
     */
    public function uninstall()
    {
        // Vérifier si la méthode parent existe
        if (!method_exists(parent::class, 'uninstall')) {
            return false;
        }
        
        // Suppression des onglets d'administration
        if (!$this->uninstallTabs()) {
            return false;
        }
        
        // Suppression des tables SQL
        if (!$this->uninstallDb()) {
            return false;
        }
        
        // Suppression de la configuration
        $this->deleteByName('IABOT_ENABLED');
        $this->deleteByName('IABOT_API_KEY');
        $this->deleteByName('IABOT_API_URL');
        $this->deleteByName('IABOT_POSITION');
        $this->deleteByName('IABOT_THEME');
        $this->deleteByName('IABOT_TITLE');
        $this->deleteByName('IABOT_SUBTITLE');
        
        // Désinstallation du module parent
        if (!parent::uninstall()) {
            return false;
        }
        
        return true;
    }

    /**
     * Installation des tables SQL
     *
     * @return bool
     */
    protected function installDb()
    {
        $sql_file = dirname(__FILE__) . '/sql/install.php';
        if (file_exists($sql_file)) {
            // Inclure le fichier PHP qui définit la variable $sql
            $sql = [];
            include($sql_file);
            
            // Exécuter chaque requête SQL
            foreach ($sql as $query) {
                if (!empty(trim($query)) && !Db::getInstance()->execute(trim($query))) {
                    return false;
                }
            }
        } else {
            // Le fichier SQL n'existe pas
            return false;
        }
        
        return true;
    }
    
    /**
     * Désinstallation des tables SQL
     *
     * @return bool
     */
    protected function uninstallDb()
    {
        $sql_file = dirname(__FILE__) . '/sql/uninstall.php';
        if (file_exists($sql_file)) {
            // Inclure le fichier PHP qui définit la variable $sql
            $sql = [];
            include($sql_file);
            
            // Exécuter chaque requête SQL
            foreach ($sql as $query) {
                if (!empty(trim($query)) && !Db::getInstance()->execute(trim($query))) {
                    return false;
                }
            }
        } else {
            // Le fichier SQL n'existe pas
            return false;
        }
        
        return true;
    }
    
    /**
     * Installation de la configuration par défaut
     *
     * @return bool
     */
    protected function installDefaultConfig()
    {
        $config = [
            'IABOT_ENABLED' => 1,
            'IABOT_POSITION' => 'right',
            'IABOT_THEME' => 'light',
            'IABOT_TITLE' => $this->l('Assistant IA'),
            'IABOT_SUBTITLE' => $this->l('Comment puis-je vous aider ?')
        ];
        
        foreach ($config as $key => $value) {
            if (!Configuration::updateValue($key, $value)) {
                return false;
            }
        }
        
        return true;
    }
    
    /**
     * Désinstallation de la configuration
     *
     * @return bool
     */
    protected function uninstallConfig()
    {
        $config = [
            'IABOT_ENABLED',
            'IABOT_POSITION',
            'IABOT_THEME',
            'IABOT_TITLE',
            'IABOT_SUBTITLE'
        ];
        
        foreach ($config as $key) {
            if (method_exists('Configuration', 'deleteByName')) {
                if (!$this->deleteByName($key)) {
                    return false;
                }
            } else {
                // Fallback si la méthode n'existe pas
                Db::getInstance()->delete('configuration', 'name = \'' . pSQL($key) . '\'');
            }
        }
        
        return true;
    }
    
    /**
     * Supprimer une configuration par son nom
     *
     * @param string $name Nom de la configuration
     * @return bool
     */
    public function deleteByName($name)
    {
        if (method_exists('\Configuration', 'deleteByName')) {
            return \Configuration::deleteByName($name);
        }
        
        // Fallback si la méthode n'existe pas
        if (!$this->db) {
            return false;
        }
        
        $sql = 'DELETE FROM `' . _DB_PREFIX_ . 'configuration` WHERE `name` = \'' . pSQL($name) . '\'';
        return $this->db->execute($sql);
    }

    /**
     * Obtenir l'ID de la dernière insertion
     * 
     * @return int
     */
    protected function getLastInsertId()
    {
        // Vérifier si la propriété db est définie
        if (!isset($this->db) || !$this->db) {
            return 0;
        }
        
        // Vérifier quelle méthode est disponible
        if (method_exists($this->db, 'Insert_ID')) {
            return $this->db->Insert_ID();
        } elseif (method_exists($this->db, 'insertId')) {
            return $this->db->insertId();
        }
        
        return 0;
    }

    /**
     * Vider le cache
     */
    public function clearCache()
    {
        // Vider le cache Smarty
        $this->clearSmartyCache();
        
        // Vider le cache de configuration
        if (method_exists('Configuration', 'clearConfigurationCacheForTesting')) {
            Configuration::clearConfigurationCacheForTesting();
        } else {
            // Fallback pour les anciennes versions
            $this->clearConfigCache();
        }
        
        return true;
    }
    
    /**
     * Vider le cache Smarty
     */
    public function clearSmartyCache()
    {
        if (isset($this->smarty) && method_exists($this->smarty, 'clearAllCache')) {
            $this->smarty->clearAllCache();
        } else {
            // Fallback pour les anciennes versions
            $this->clearSmartyDirectoryCache();
        }
        
        return true;
    }
    
    /**
     * Vider le cache de configuration
     */
    protected function clearConfigCache()
    {
        // Vérifier si la méthode Configuration::clearConfigurationCacheForTesting existe
        if (method_exists('Configuration', 'clearConfigurationCacheForTesting')) {
            Configuration::clearConfigurationCacheForTesting();
        } elseif (method_exists('Configuration', 'clearCache')) {
            Configuration::clearCache();
        } else {
            // Fallback si aucune méthode n'existe
            $this->clearCache();
        }
    }
    
    /**
     * Vider le cache Smarty en supprimant les fichiers du répertoire
     */
    protected function clearSmartyDirectoryCache()
    {
        $cacheDir = defined('_PS_CACHE_DIR_') ? _PS_CACHE_DIR_ . 'smarty/cache' : _PS_ROOT_DIR_ . '/var/cache/smarty/cache';
        if (is_dir($cacheDir)) {
            $files = glob($cacheDir . '/*');
            if ($files) {
                foreach ($files as $file) {
                    if (is_file($file)) {
                        @unlink($file);
                    } elseif (is_dir($file)) {
                        $this->deleteDirectory($file);
                    }
                }
            }
        }
        
        return true;
    }
    
    /**
     * Supprimer un répertoire et son contenu
     *
     * @param string $dir Chemin du répertoire
     * @return bool
     */
    protected function deleteDirectory($dir)
    {
        if (!is_dir($dir)) {
            return false;
        }
        
        $files = array_diff(scandir($dir), ['.', '..']);
        foreach ($files as $file) {
            $path = $dir . '/' . $file;
            if (is_dir($path)) {
                $this->deleteDirectory($path);
            } else {
                @unlink($path);
            }
        }
        
        return @rmdir($dir);
    }
    
    /**
     * Obtenir l'adresse IP du client
     * 
     * @return string
     */
    protected function getRemoteAddr()
    {
        // Vérifier si la classe Tools existe et si la méthode getRemoteAddr existe
        if (class_exists('Tools') && method_exists('Tools', 'getRemoteAddr')) {
            return Tools::getRemoteAddr();
        }
        
        // Fallback si la méthode n'existe pas
        $ip_keys = [
            'HTTP_CLIENT_IP',
            'HTTP_X_FORWARDED_FOR',
            'HTTP_X_FORWARDED',
            'HTTP_X_CLUSTER_CLIENT_IP',
            'HTTP_FORWARDED_FOR',
            'HTTP_FORWARDED',
            'REMOTE_ADDR'
        ];
        
        foreach ($ip_keys as $key) {
            if (isset($_SERVER[$key]) && filter_var($_SERVER[$key], FILTER_VALIDATE_IP)) {
                return $_SERVER[$key];
            }
        }
        
        return '127.0.0.1';
    }
    
    /**
     * Générer un token de sécurité
     * 
     * @param string $page Nom de la page
     * @return string
     */
    protected function getToken($page = null)
    {
        // Vérifier si la classe Tools existe et si la méthode getToken existe
        if (class_exists('Tools') && method_exists('Tools', 'getToken')) {
            return Tools::getToken(false);
        } elseif (class_exists('Tools') && method_exists('Tools', 'getAdminToken')) {
            // Fallback si la méthode getToken n'existe pas
            $page = $page ?: 'AdminModules';
            $employee_id = isset($this->employee) && $this->employee ? (int)$this->employee->id : 0;
            return Tools::getAdminToken($page . (int)$employee_id . (int)$this->id);
        }
        
        // Fallback si aucune méthode n'existe
        $key = defined('_COOKIE_KEY_') ? _COOKIE_KEY_ : 'iabot_default_key';
        $employee_id = isset($this->employee) && $this->employee ? (int)$this->employee->id : 0;
        return md5($key . $employee_id . (int)$this->id);
    }

    /**
     * Traduction d'une chaîne
     * 
     * @param string $string Chaîne à traduire
     * @param string|bool $specific Module spécifique
     * @return string
     */
    public function l($string, $specific = false)
    {
        // Vérifier si la méthode parent existe
        if (method_exists(parent::class, 'l')) {
            return parent::l($string, $specific);
        }
        
        // Fallback si la méthode n'existe pas
        if (class_exists('\Translate')) {
            if (method_exists('\Translate', 'getModuleTranslation')) {
                return \Translate::getModuleTranslation($this->name, $string, $specific ?: $this->name);
            }
        }
        
        return $string;
    }

    /**
     * Récupérer le chemin local du module
     */
    public function getLocalPath()
    {
        return _PS_MODULE_DIR_ . $this->name . '/';
    }

    /**
     * Affichage du widget
     * 
     * @param string $hookName    Nom du hook
     * @param array  $configuration Configuration
     * 
     * @return string
     */
    public function renderWidget(string $hookName, array $configuration): string
    {
        // Vérifier si le contexte est disponible
        if (!isset($this->context) || !$this->context) {
            return '';
        }
        
        // Récupérer les variables du widget
        $variables = $this->getWidgetVariables($hookName, $configuration);
        
        // Assigner les variables au template
        if (isset($this->context->smarty)) {
            $this->context->smarty->assign($variables);
            
            // Récupérer le contenu du template
            if (method_exists($this->context->smarty, 'fetch')) {
                return $this->context->smarty->fetch('module:' . $this->name . '/views/templates/hook/' . $hookName . '.tpl');
            }
        }
        
        return '';
    }
    
    /**
     * Récupérer les variables du widget
     *
     * @param string $hookName    Nom du hook
     * @param array  $configuration Configuration
     *
     * @return array
     */
    public function getWidgetVariables(string $hookName, array $configuration = []): array
    {
        return [
            'iabot_enabled' => (bool)Configuration::get('IABOT_ENABLED', true),
            'iabot_position' => Configuration::get('IABOT_POSITION', 'right'),
            'iabot_theme' => Configuration::get('IABOT_THEME', 'light'),
            'iabot_title' => Configuration::get('IABOT_TITLE', $this->l('Assistant IA')),
            'iabot_subtitle' => Configuration::get('IABOT_SUBTITLE', $this->l('Comment puis-je vous aider ?')),
            'iabot_module_dir' => $this->_path,
            'iabot_ajax_url' => isset($this->context->link) ? $this->context->link->getModuleLink($this->name, 'ajax', [], true) : '',
        ];
    }

    /**
     * Affichage du script avant la fermeture du body
     */
    public function hookDisplayBeforeBodyClosingTag($params)
    {
        // Vérifier si le contexte est disponible
        if (!isset($this->context) || !$this->context) {
            return '';
        }
        
        // Vérifier si Smarty est disponible
        if (!isset($this->context->smarty)) {
            return '';
        }
        
        // Assigner les variables au template
        $this->context->smarty->assign([
            'iabot_enabled' => (bool)Configuration::get('IABOT_ENABLED', true),
            'iabot_position' => Configuration::get('IABOT_POSITION', 'right'),
            'iabot_theme' => Configuration::get('IABOT_THEME', 'light'),
            'iabot_title' => Configuration::get('IABOT_TITLE', $this->l('Assistant IA')),
            'iabot_subtitle' => Configuration::get('IABOT_SUBTITLE', $this->l('Comment puis-je vous aider ?')),
            'iabot_module_dir' => $this->_path,
            'iabot_ajax_url' => isset($this->context->link) ? $this->context->link->getModuleLink($this->name, 'ajax', [], true) : '',
        ]);

        // Récupérer le contenu du template
        if (method_exists($this->context->smarty, 'fetch')) {
            return $this->context->smarty->fetch('module:' . $this->name . '/views/templates/front/scripts.tpl');
        }
        
        return '';
    }

    /**
     * Installation des onglets d'administration
     *
     * @return bool
     */
    public function installTabs()
    {
        // Vérifier si la classe Tab existe
        if (!class_exists('Tab')) {
            return false;
        }
        
        // Création de l'onglet principal
        $tab = new Tab();
        $tab->active = 1;
        $tab->class_name = 'AdminIaBot';
        $tab->name = array();
        $tab->icon = $this->icon;
        
        // Vérifier si la méthode getIdFromClassName existe
        if (method_exists('Tab', 'getIdFromClassName')) {
            $tab->id_parent = Tab::getIdFromClassName('SELL');
        } else {
            // Valeur par défaut si la méthode n'existe pas
            $tab->id_parent = 0;
        }
        
        $tab->module = $this->name;

        // Vérifier si la classe Language existe
        if (class_exists('Language')) {
            foreach (Language::getLanguages() as $lang) {
                if (isset($lang['id_lang'])) {
                    $tab->name[$lang['id_lang']] = 'Assistant IA';
                }
            }
        } else {
            // Fallback si Language n'existe pas
            $tab->name[1] = 'Assistant IA';
        }

        // Vérifier si la méthode save existe
        if (method_exists($tab, 'save')) {
            if (!$tab->save()) {
                return false;
            }
        } else {
            // Fallback si la méthode save n'existe pas
            $db = Db::getInstance();
            $db->insert('tab', [
                'class_name' => pSQL($tab->class_name),
                'module' => pSQL($tab->module),
                'id_parent' => (int)$tab->id_parent,
                'active' => (int)$tab->active
            ]);
            
            $tabId = $this->getLastInsertId();
            
            if ($tabId) {
                foreach ($tab->name as $langId => $name) {
                    $db->insert('tab_lang', [
                        'id_tab' => (int)$tabId,
                        'id_lang' => (int)$langId,
                        'name' => pSQL($name)
                    ]);
                }
            }
        }

        // Ajout des permissions pour l'employé actuel
        if (isset($this->context) && isset($this->context->employee) && 
            isset($this->context->employee->id) && isset($tab->id)) {
            $this->addTabPermission($tab->id, $this->context->employee->id);
        }

        return true;
    }

    /**
     * Désinstallation des onglets d'administration
     *
     * @return bool
     */
    public function uninstallTabs()
    {
        // Vérifier si la classe Tab existe et si la méthode getIdFromClassName existe
        if (class_exists('Tab') && method_exists('Tab', 'getIdFromClassName')) {
            $tabId = Tab::getIdFromClassName('AdminIaBot');
            if ($tabId) {
                $tab = new Tab($tabId);
                if (method_exists($tab, 'delete')) {
                    return $tab->delete();
                } else {
                    // Fallback si la méthode delete n'existe pas
                    $db = Db::getInstance();
                    $db->delete('tab', 'id_tab = ' . (int)$tabId);
                    $db->delete('tab_lang', 'id_tab = ' . (int)$tabId);
                    return true;
                }
            }
        } else {
            // Fallback si Tab n'existe pas ou getIdFromClassName n'existe pas
            $db = Db::getInstance();
            $tabId = $db->getValue('SELECT id_tab FROM `' . _DB_PREFIX_ . 'tab` WHERE class_name = "AdminIaBot"');
            if ($tabId) {
                $db->delete('tab', 'id_tab = ' . (int)$tabId);
                $db->delete('tab_lang', 'id_tab = ' . (int)$tabId);
            }
        }
        return true;
    }

    /**
     * Ajouter les permissions sur un onglet pour un employé
     *
     * @param int $idTab ID de l'onglet
     * @param int $idEmployee ID de l'employé
     * @return bool
     */
    protected function addTabPermission($idTab, $idEmployee)
    {
        // Vérifier si la base de données est disponible
        $db = Db::getInstance();
        if (!$db) {
            return false;
        }
        
        // Vérifier si la table des autorisations existe
        $tablePermission = _DB_PREFIX_ . 'authorization_role';
        $tablePermissionExists = $db->getValue("SHOW TABLES LIKE '" . pSQL($tablePermission) . "'") ? true : false;

        if ($tablePermissionExists) {
            // PrestaShop 1.7+ utilise des rôles d'autorisation
            $roles = ['CREATE', 'READ', 'UPDATE', 'DELETE'];
            
            if (class_exists('Tab')) {
                $tab = new Tab($idTab);
                $className = $tab->class_name;

                foreach ($roles as $role) {
                    $slug = "ROLE_MOD_TAB_" . strtoupper($this->name) . "_" . strtoupper($className) . "_" . $role;
                    $roleId = $db->getValue(
                        "SELECT id_authorization_role FROM `" . _DB_PREFIX_ . "authorization_role` 
                         WHERE slug = '" . pSQL($slug) . "'"
                    );

                    if (!$roleId) {
                        $db->execute(
                            "INSERT INTO `" . _DB_PREFIX_ . "authorization_role` (`slug`) 
                             VALUES ('" . pSQL($slug) . "')"
                        );
                        $roleId = (int)$this->getLastInsertId();
                    }

                    if ($roleId) {
                        $db->execute(
                            'INSERT IGNORE INTO `' . _DB_PREFIX_ . 'access` (`id_profile`, `id_authorization_role`) 
                             VALUES (1, ' . (int)$roleId . ')'
                        );

                        $db->execute(
                            'INSERT IGNORE INTO `' . _DB_PREFIX_ . 'module_access` (`id_profile`, `id_authorization_role`) 
                             VALUES (1, ' . (int)$roleId . ')'
                        );
                    }
                }
            }
        }

        return true;
    }

    /**
     * Vérifier si le nom du hook est valide
     * 
     * @param string $hook_name Nom du hook
     * @return bool
     */
    protected function isValidHookName($hook_name)
    {
        return is_string($hook_name) && !empty($hook_name);
    }
    
    /**
     * Récupérer l'ID d'un hook par son nom
     * 
     * @param string $hook_name Nom du hook
     * @return int|bool
     */
    protected function getHookIdByName($hook_name)
    {
        if (!$this->db) {
            return false;
        }
        
        $sql = 'SELECT `id_hook` FROM `' . _DB_PREFIX_ . 'hook` WHERE `name` = \'' . pSQL($hook_name) . '\'';
        $result = $this->db->getRow($sql);
        
        return isset($result['id_hook']) ? (int)$result['id_hook'] : false;
    }
    
    /**
     * Créer un nouveau hook
     * 
     * @param string $hook_name Nom du hook
     * @return int|bool
     */
    protected function createHook($hook_name)
    {
        if (!$this->db) {
            return false;
        }
        
        $sql = 'INSERT IGNORE INTO `' . _DB_PREFIX_ . 'hook` (`name`, `title`, `description`)
                VALUES (\'' . pSQL($hook_name) . '\', \'' . pSQL($hook_name) . '\', \'\')';
        
        if (!$this->db->execute($sql)) {
            return false;
        }
        
        return $this->getHookIdByName($hook_name);
    }

    /**
     * Enregistrement d'un hook
     *
     * @param string $hook_name Nom du hook
     * @return bool
     */
    public function registerHook($hook_name)
    {
        // Vérifier si le nom du hook est valide
        if (!$this->isValidHookName($hook_name)) {
            return false;
        }
        
        // Vérifier si la méthode parent existe
        if (method_exists(parent::class, 'registerHook')) {
            return parent::registerHook($hook_name);
        }
        
        // Fallback si la méthode n'existe pas
        $hook_id = $this->getHookIdByName($hook_name);
        if (!$hook_id) {
            $hook_id = $this->createHook($hook_name);
        }
        
        if (!$hook_id) {
            return false;
        }
        
        // Vérifier si l'ID du module est défini
        if (!isset($this->id) || !$this->id) {
            return false;
        }
        
        // Enregistrer le hook
        $sql = 'INSERT IGNORE INTO `' . _DB_PREFIX_ . 'hook_module` (`id_module`, `id_hook`, `position`)
                VALUES (' . (int)$this->id . ', ' . (int)$hook_id . ', 
                (SELECT IFNULL(MAX(position), 0) + 1 FROM `' . _DB_PREFIX_ . 'hook_module` WHERE `id_hook` = ' . (int)$hook_id . '))';
        
        return $this->db && $this->db->execute($sql);
    }
}
